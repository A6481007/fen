﻿"use client";

import { FormEvent, useMemo, useState, useTransition } from "react";
import Link from "next/link";
import { useRouter } from "next/navigation";
import { FormTabs, type FormSection } from "@/components/admin/backoffice/FormTabs";
import { PortableTextEditor } from "@/components/admin/backoffice/PortableTextEditor";
import { ReferencePicker, type ReferenceOption } from "@/components/admin/backoffice/ReferencePicker";
import { AssetUploader } from "@/components/admin/backoffice/AssetUploader";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Textarea } from "@/components/ui/textarea";
import { useToast } from "@/hooks/use-toast";
import type { NewsAttachment, NewsFormState } from "./types";
import { useTranslation } from "react-i18next";

type AttachmentDraft = {
  title: string;
  description: string;
  fileType: string;
  status: string;
  assetId?: string | null;
};

type NewsFormProps = {
  initialValues?: Partial<NewsFormState>;
  initialLinkedEvent?: ReferenceOption | null;
  initialAttachments?: NewsAttachment[];
  basePath?: string;
  onSubmit: (values: NewsFormState) => Promise<{
    success: boolean;
    id?: string;
    status?: string;
    message?: string;
  }>;
  onAddAttachment?: (payload: {
    title: string;
    description?: string;
    fileType: string;
    status: string;
    assetId?: string | null;
  }) => Promise<{ success: boolean; attachments?: NewsAttachment[]; message?: string }>;
  onRemoveAttachment?: (attachmentKey: string) => Promise<{
    success: boolean;
    attachments?: NewsAttachment[];
    message?: string;
  }>;
  searchEvents: (query: string) => Promise<ReferenceOption[]>;
};

const categoryOptions = [
  { value: "announcement", labelKey: "admin.news.category.announcement", defaultLabel: "Announcement" },
  { value: "partnership", labelKey: "admin.news.category.partnership", defaultLabel: "Partnership" },
  { value: "event_announcement", labelKey: "admin.news.category.eventAnnouncement", defaultLabel: "Event Announcement" },
  { value: "general", labelKey: "admin.news.category.general", defaultLabel: "General" },
] as const;

const statusOptions = [
  { value: "draft", labelKey: "admin.news.status.draft", defaultLabel: "Draft" },
  { value: "published", labelKey: "admin.news.status.published", defaultLabel: "Published" },
] as const;

const fileTypeOptions = [
  { value: "PDF", labelKey: "admin.news.attachments.fileType.pdf", defaultLabel: "PDF" },
  { value: "image", labelKey: "admin.news.attachments.fileType.image", defaultLabel: "Image" },
  { value: "document", labelKey: "admin.news.attachments.fileType.document", defaultLabel: "Document" },
  { value: "link", labelKey: "admin.news.attachments.fileType.link", defaultLabel: "Link" },
] as const;

const attachmentStatusOptions = [
  { value: "public", labelKey: "admin.news.attachments.access.public", defaultLabel: "Public" },
  { value: "event_locked", labelKey: "admin.news.attachments.access.eventLocked", defaultLabel: "Event Locked" },
] as const;

const statusBadge: Record<string, "default" | "secondary"> = {
  published: "default",
  draft: "secondary",
};

const slugify = (value: string) =>
  value
    .toLowerCase()
    .replace(/[^a-z0-9]+/g, "-")
    .replace(/^-+|-+$/g, "")
    .slice(0, 96);

const toDateTimeInputValue = (value?: string) => {
  if (!value) return "";
  const date = new Date(value);
  if (Number.isNaN(date.getTime())) return "";
  const pad = (input: number) => `${input}`.padStart(2, "0");
  return `${date.getFullYear()}-${pad(date.getMonth() + 1)}-${pad(date.getDate())}T${pad(date.getHours())}:${pad(date.getMinutes())}`;
};

const buildInitialState = (
  values?: Partial<NewsFormState>,
  linkedEvent?: ReferenceOption | null,
): NewsFormState => ({
  _id: values?._id,
  title: values?.title ?? "",
  slug: values?.slug ?? "",
  publishDate: toDateTimeInputValue(values?.publishDate ?? new Date().toISOString()),
  category: values?.category ?? "general",
  status: values?.status ?? "draft",
  content: values?.content ?? [],
  linkedEventId: values?.linkedEventId ?? linkedEvent?.id ?? null,
});

const NewsForm = ({
  initialValues,
  initialLinkedEvent,
  initialAttachments,
  basePath,
  onSubmit,
  onAddAttachment,
  onRemoveAttachment,
  searchEvents,
}: NewsFormProps) => {
  const router = useRouter();
  const { toast } = useToast();
  const { t } = useTranslation();
  const resolveMessage = (message: string | undefined, fallbackKey: string) => {
    if (!message) return t(fallbackKey);
    return message.startsWith("admin.") ? t(message) : message;
  };
  const resolvedBasePath = basePath ?? "/admin/content/news";
  const resolvedLinkedEvent = useMemo(() => {
    if (!initialLinkedEvent) return null;
    const label = initialLinkedEvent.label?.trim() || t("admin.content.news.fallback.event");
    return { ...initialLinkedEvent, label };
  }, [initialLinkedEvent, t]);
  const [formState, setFormState] = useState<NewsFormState>(
    buildInitialState(initialValues, resolvedLinkedEvent),
  );
  const optionLabel = (
    options: { value: string; labelKey: string; defaultLabel: string }[],
    value?: string | null,
  ) => {
    if (!value) return "";
    const option = options.find((item) => item.value === value);
    return option ? t(option.labelKey, option.defaultLabel) : value;
  };
  const [linkedEvent, setLinkedEvent] = useState<ReferenceOption | null>(resolvedLinkedEvent ?? null);
  const [slugDirty, setSlugDirty] = useState(Boolean(initialValues?.slug));
  const [attachments, setAttachments] = useState<NewsAttachment[]>(initialAttachments ?? []);
  const [attachmentDraft, setAttachmentDraft] = useState<AttachmentDraft>({
    title: "",
    description: "",
    fileType: "PDF",
    status: "public",
    assetId: null,
  });
  const [submitError, setSubmitError] = useState<string | null>(null);
  const [attachmentError, setAttachmentError] = useState<string | null>(null);
  const [removingKey, setRemovingKey] = useState<string | null>(null);
  const [isPending, startTransition] = useTransition();
  const [isAttachmentPending, startAttachmentTransition] = useTransition();

  const handleTitleChange = (value: string) => {
    setFormState((prev) => ({
      ...prev,
      title: value,
      slug: slugDirty ? prev.slug : slugify(value),
    }));
  };

  const handleSlugChange = (value: string) => {
    setSlugDirty(true);
    setFormState((prev) => ({ ...prev, slug: value }));
  };

  const handleSubmit = (event: FormEvent<HTMLFormElement>) => {
    event.preventDefault();
    const slugValue = (formState.slug || slugify(formState.title)).trim();

    if (!slugValue) {
      setSubmitError(t("admin.news.errors.slugRequired"));
      return;
    }

    const publishDateIso = formState.publishDate
      ? new Date(formState.publishDate).toISOString()
      : new Date().toISOString();

    const payload: NewsFormState = {
      ...formState,
      slug: slugValue,
      publishDate: publishDateIso,
    };

    startTransition(() => {
      onSubmit(payload)
        .then((result) => {
          if (!result.success) {
            setSubmitError(resolveMessage(result.message, "admin.news.errors.saveFailed"));
            toast({
              description: resolveMessage(result.message, "admin.news.errors.saveFailed"),
            });
            return;
          }

          setSubmitError(null);
          toast({ description: t("admin.news.toast.saved") });

          if (!payload._id && result.id) {
            router.replace(`${resolvedBasePath}/${result.id}`);
          } else if (result.id) {
            setFormState((prev) => ({ ...prev, _id: result.id }));
          }
        })
        .catch((error) => {
          console.error("Failed to save news", error);
          setSubmitError(t("admin.news.errors.saveFailed"));
          toast({ description: t("admin.news.errors.saveFailedNow") });
        });
    });
  };

  const handleAddAttachment = () => {
    if (!onAddAttachment || !formState._id) {
      setAttachmentError(t("admin.news.attachments.errors.saveFirst"));
      return;
    }

    if (!attachmentDraft.title.trim()) {
      setAttachmentError(t("admin.news.attachments.errors.titleRequired"));
      return;
    }

    if (!attachmentDraft.assetId && attachmentDraft.fileType !== "link") {
      setAttachmentError(t("admin.news.attachments.errors.fileRequired"));
      return;
    }

    setAttachmentError(null);
    startAttachmentTransition(() => {
      onAddAttachment({
        title: attachmentDraft.title.trim(),
        description: attachmentDraft.description.trim() || undefined,
        fileType: attachmentDraft.fileType,
        status: attachmentDraft.status,
        assetId: attachmentDraft.assetId,
      })
        .then((result) => {
          if (!result.success || !result.attachments) {
            setAttachmentError(resolveMessage(result.message, "admin.news.attachments.errors.addFailed"));
            toast({ description: resolveMessage(result.message, "admin.news.attachments.errors.addFailed") });
            return;
          }

          setAttachments(result.attachments);
          setAttachmentDraft({
            title: "",
            description: "",
            fileType: "PDF",
            status: "public",
            assetId: null,
          });
          toast({ description: t("admin.news.attachments.toast.added") });
        })
        .catch((error) => {
          console.error("Failed to add attachment", error);
          setAttachmentError(t("admin.news.attachments.errors.addFailed"));
          toast({ description: t("admin.news.attachments.errors.addFailedNow") });
        });
    });
  };

  const handleRemoveAttachment = (attachmentKey?: string) => {
    if (!attachmentKey || !onRemoveAttachment || !formState._id) return;

    setRemovingKey(attachmentKey);
    startAttachmentTransition(() => {
      onRemoveAttachment(attachmentKey)
        .then((result) => {
          if (!result.success || !result.attachments) {
            toast({ description: resolveMessage(result.message, "admin.news.attachments.errors.removeFailed") });
            return;
          }
          setAttachments(result.attachments);
          toast({ description: t("admin.news.attachments.toast.removed") });
        })
        .catch((error) => {
          console.error("Failed to remove attachment", error);
          toast({ description: t("admin.news.attachments.errors.removeFailedNow") });
        })
        .finally(() => setRemovingKey(null));
    });
  };

  const sections: FormSection[] = useMemo(() => {
    const basics = (
      <div className="grid gap-4 md:grid-cols-2">
        <div className="space-y-2">
          <Label htmlFor="title">{t("admin.news.fields.title")}</Label>
          <Input
            id="title"
            value={formState.title}
            onChange={(event) => handleTitleChange(event.target.value)}
            placeholder={t("admin.news.fields.titlePlaceholder")}
          />
        </div>

        <div className="space-y-2">
          <div className="flex items-center justify-between">
            <Label htmlFor="slug">{t("admin.news.fields.slug")}</Label>
            <Button
              variant="ghost"
              size="sm"
              type="button"
              onClick={() => handleSlugChange(slugify(formState.title))}
            >
              {t("admin.news.actions.regenerate")}
            </Button>
          </div>
          <Input
            id="slug"
            value={formState.slug}
            onChange={(event) => handleSlugChange(event.target.value)}
            placeholder={t("admin.news.fields.slugPlaceholder")}
          />
        </div>

        <div className="space-y-2">
          <Label htmlFor="publishDate">{t("admin.news.fields.publishDate")}</Label>
          <Input
            id="publishDate"
            type="datetime-local"
            value={formState.publishDate}
            onChange={(event) => setFormState((prev) => ({ ...prev, publishDate: event.target.value }))}
          />
        </div>

        <div className="space-y-2">
          <Label htmlFor="category">{t("admin.news.fields.category")}</Label>
          <Select
            value={formState.category}
            onValueChange={(value) => setFormState((prev) => ({ ...prev, category: value }))}
          >
            <SelectTrigger id="category">
              <SelectValue placeholder={t("admin.news.fields.categoryPlaceholder")} />
            </SelectTrigger>
            <SelectContent>
              {categoryOptions.map((option) => (
                <SelectItem key={option.value} value={option.value}>
                  {t(option.labelKey, option.defaultLabel)}
                </SelectItem>
              ))}
            </SelectContent>
          </Select>
        </div>

        <div className="space-y-2">
          <Label htmlFor="status">{t("admin.news.fields.status")}</Label>
          <Select
            value={formState.status ?? "draft"}
            onValueChange={(value) => setFormState((prev) => ({ ...prev, status: value as NewsFormState["status"] }))}
          >
            <SelectTrigger id="status">
              <SelectValue placeholder={t("admin.news.fields.statusPlaceholder")} />
            </SelectTrigger>
            <SelectContent>
              {statusOptions.map((option) => (
                <SelectItem key={option.value} value={option.value}>
                  {t(option.labelKey, option.defaultLabel)}
                </SelectItem>
              ))}
            </SelectContent>
          </Select>
        </div>

        <div className="md:col-span-2 flex items-center gap-2">
          <Badge variant={statusBadge[formState.status ?? "draft"] ?? "secondary"} className="capitalize">
            {optionLabel(statusOptions, formState.status ?? "draft")}
          </Badge>
          <p className="text-xs text-slate-500">
            {t("admin.news.fields.statusHint")}
          </p>
        </div>
      </div>
    );

    const content = (
      <div className="space-y-4">
        <div className="space-y-2">
          <Label htmlFor="content">{t("admin.news.fields.body")}</Label>
          <PortableTextEditor
            label={t("admin.news.fields.bodyLabel")}
            description={t("admin.news.fields.bodyDescription")}
            value={formState.content ?? []}
            onChange={(body) => setFormState((prev) => ({ ...prev, content: body }))}
            minRows={10}
          />
        </div>
      </div>
    );

    const relationships = (
      <div className="space-y-6">
        <ReferencePicker
          label={t("admin.news.relationships.linkedEvent")}
          placeholder={t("admin.news.relationships.searchEvents")}
          value={linkedEvent}
          onChange={(option) => {
            setLinkedEvent(option);
            setFormState((prev) => ({ ...prev, linkedEventId: option?.id ?? null }));
          }}
          onSearch={(query) => searchEvents(query)}
          description={t("admin.news.relationships.eventLockedHint")}
        />

        <div className="space-y-3 rounded-lg border border-slate-200 bg-slate-50 p-4">
          <div className="flex items-center justify-between">
            <div className="space-y-1">
              <p className="text-sm font-semibold text-slate-800">{t("admin.news.attachments.title")}</p>
              <p className="text-xs text-slate-600">
                {t("admin.news.attachments.subtitle")}
              </p>
            </div>
            {attachments.length ? (
              <Badge variant="secondary">{t("admin.news.attachments.attachedCount", { count: attachments.length })}</Badge>
            ) : null}
          </div>

          {attachments.length === 0 ? (
            <div className="rounded-lg border border-dashed border-slate-200 bg-white p-4 text-sm text-slate-600">
              {t("admin.news.attachments.empty")}
            </div>
          ) : (
            <div className="space-y-3">
              {attachments.map((attachment) => (
                <div
                  key={attachment._key ?? attachment.title ?? "attachment"}
                  className="flex flex-col gap-3 rounded-lg border border-slate-200 bg-white p-3 md:flex-row md:items-center md:justify-between"
                >
                  <div className="space-y-1">
                    <p className="font-semibold text-slate-900">
                      {attachment.title ?? t("admin.news.attachments.attachmentFallback")}
                    </p>
                    {attachment.description ? (
                      <p className="text-sm text-slate-600">{attachment.description}</p>
                    ) : null}
                    <div className="flex flex-wrap gap-2 text-xs text-slate-600">
                      <Badge variant="outline" className="capitalize">
                        {attachment.fileType
                          ? optionLabel(fileTypeOptions, attachment.fileType)
                          : t("admin.news.attachments.fileType.file")}
                      </Badge>
                      <Badge variant="outline" className="capitalize">
                        {attachment.status
                          ? optionLabel(attachmentStatusOptions, attachment.status)
                          : t("admin.news.attachments.access.public")}
                      </Badge>
                      {attachment.file?.asset?.originalFilename ? (
                        <span className="rounded-full bg-slate-100 px-2 py-1">
                          {attachment.file.asset.originalFilename}
                        </span>
                      ) : attachment.file?.asset?._ref ? (
                        <span className="rounded-full bg-slate-100 px-2 py-1">
                          {attachment.file.asset._ref}
                        </span>
                      ) : null}
                    </div>
                  </div>
                  {onRemoveAttachment && formState._id ? (
                    <Button
                      variant="ghost"
                      size="sm"
                      onClick={() => handleRemoveAttachment(attachment._key)}
                      disabled={isAttachmentPending && removingKey === attachment._key}
                    >
                      {isAttachmentPending && removingKey === attachment._key
                        ? t("admin.news.attachments.removing")
                        : t("admin.news.attachments.remove")}
                    </Button>
                  ) : null}
                </div>
              ))}
            </div>
          )}

          <div className="grid gap-3 md:grid-cols-2">
            <div className="space-y-2">
              <Label htmlFor="attachmentTitle">{t("admin.news.attachments.titleLabel")}</Label>
              <Input
                id="attachmentTitle"
                value={attachmentDraft.title}
                onChange={(event) => setAttachmentDraft((prev) => ({ ...prev, title: event.target.value }))}
                placeholder={t("admin.news.attachments.titlePlaceholder")}
                disabled={!formState._id}
              />
            </div>
            <div className="space-y-2">
              <Label htmlFor="attachmentType">{t("admin.news.attachments.fileTypeLabel")}</Label>
              <Select
                value={attachmentDraft.fileType}
                onValueChange={(value) => setAttachmentDraft((prev) => ({ ...prev, fileType: value }))}
                disabled={!formState._id}
              >
                <SelectTrigger id="attachmentType">
                  <SelectValue placeholder={t("admin.news.attachments.fileTypePlaceholder")} />
                </SelectTrigger>
                <SelectContent>
                  {fileTypeOptions.map((option) => (
                    <SelectItem key={option.value} value={option.value}>
                      {t(option.labelKey, option.defaultLabel)}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
            <div className="space-y-2">
              <Label htmlFor="attachmentStatus">{t("admin.news.attachments.accessLabel")}</Label>
              <Select
                value={attachmentDraft.status}
                onValueChange={(value) => setAttachmentDraft((prev) => ({ ...prev, status: value }))}
                disabled={!formState._id}
              >
                <SelectTrigger id="attachmentStatus">
                  <SelectValue placeholder={t("admin.news.attachments.accessPlaceholder")} />
                </SelectTrigger>
                <SelectContent>
                  {attachmentStatusOptions.map((option) => (
                    <SelectItem key={option.value} value={option.value}>
                      {t(option.labelKey, option.defaultLabel)}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
            <div className="space-y-2">
              <Label htmlFor="attachmentDescription">{t("admin.news.attachments.descriptionLabel")}</Label>
              <Textarea
                id="attachmentDescription"
                rows={2}
                value={attachmentDraft.description}
                onChange={(event) => setAttachmentDraft((prev) => ({ ...prev, description: event.target.value }))}
                placeholder={t("admin.news.attachments.descriptionPlaceholder")}
                disabled={!formState._id}
              />
            </div>
          </div>

          <AssetUploader
            label={t("admin.news.attachments.uploadLabel")}
            description={t("admin.news.attachments.uploadDescription")}
            onChange={(value) => setAttachmentDraft((prev) => ({ ...prev, assetId: value?.assetId ?? null }))}
            className="md:max-w-xl"
          />

          {attachmentError && (
            <div className="rounded-lg border border-amber-200 bg-amber-50 px-3 py-2 text-sm text-amber-800">
              {attachmentError}
            </div>
          )}

          <div className="flex justify-end">
            <Button
              type="button"
              size="sm"
              onClick={handleAddAttachment}
              disabled={!formState._id || isAttachmentPending}
            >
              {isAttachmentPending ? t("admin.news.attachments.adding") : t("admin.news.attachments.add")}
            </Button>
          </div>
        </div>
      </div>
    );

    return [
      { id: "basics", label: t("admin.news.sections.basics"), content: basics },
      { id: "content", label: t("admin.news.sections.content"), content: content },
      { id: "relationships", label: t("admin.news.sections.relationships"), content: relationships },
    ];
  }, [attachments, attachmentDraft, formState, linkedEvent, searchEvents, slugDirty, t]);

  return (
    <form onSubmit={handleSubmit} className="space-y-4">
      <div className="flex flex-wrap items-center justify-between gap-3">
        <div>
          <p className="text-lg font-semibold text-slate-900">
            {formState._id ? t("admin.news.header.edit") : t("admin.news.header.new")}
          </p>
          <p className="text-xs text-slate-600">
            {t("admin.news.header.hint")}
          </p>
        </div>
        <div className="flex items-center gap-2">
          <Button variant="outline" size="sm" asChild>
            <Link href={resolvedBasePath}>{t("admin.news.actions.cancel")}</Link>
          </Button>
          <Button type="submit" size="sm" disabled={isPending}>
            {isPending ? t("admin.news.actions.saving") : t("admin.news.actions.save")}
          </Button>
        </div>
      </div>

      {submitError && (
        <div className="rounded-lg border border-red-200 bg-red-50 px-3 py-2 text-sm text-red-700">
          {submitError}
        </div>
      )}

      {!formState._id && (
        <div className="rounded-lg border border-slate-200 bg-slate-50 px-3 py-2 text-sm text-slate-700">
          {t("admin.news.attachments.saveFirstHint")}
        </div>
      )}

      <FormTabs sections={sections} defaultSection="basics" />
    </form>
  );
};

export default NewsForm;

