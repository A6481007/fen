"use client";

import { FormEvent, useMemo, useState, useTransition } from "react";
import Link from "next/link";
import { useRouter } from "next/navigation";
import { FormTabs, type FormSection } from "@/components/admin/backoffice/FormTabs";
import { StatusBadge } from "@/components/admin/promotions/StatusBadge";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Textarea } from "@/components/ui/textarea";
import { useToast } from "@/hooks/use-toast";
import type { PromotionFormState } from "./types";
import { useTranslation } from "react-i18next";

const statusOptions = [
  { value: "draft", labelKey: "admin.promotions.form.status.draft", defaultLabel: "Draft" },
  { value: "scheduled", labelKey: "admin.promotions.form.status.scheduled", defaultLabel: "Scheduled" },
  { value: "active", labelKey: "admin.promotions.form.status.active", defaultLabel: "Active" },
  { value: "paused", labelKey: "admin.promotions.form.status.paused", defaultLabel: "Paused" },
  { value: "ended", labelKey: "admin.promotions.form.status.ended", defaultLabel: "Ended" },
] as const;

const templateOptions = [
  { value: "flashSale", labelKey: "admin.promotions.form.template.flashSale", defaultLabel: "Flash Sale" },
  { value: "seasonal", labelKey: "admin.promotions.form.template.seasonal", defaultLabel: "Seasonal" },
  { value: "bundle", labelKey: "admin.promotions.form.template.bundle", defaultLabel: "Bundle / BXGY" },
  { value: "loyalty", labelKey: "admin.promotions.form.template.loyalty", defaultLabel: "Loyalty" },
  { value: "clearance", labelKey: "admin.promotions.form.template.clearance", defaultLabel: "Clearance" },
  { value: "winBack", labelKey: "admin.promotions.form.template.winBack", defaultLabel: "Win-Back" },
  { value: "firstPurchase", labelKey: "admin.promotions.form.template.firstPurchase", defaultLabel: "First Purchase" },
  { value: "freeShipping", labelKey: "admin.promotions.form.template.freeShipping", defaultLabel: "Free Shipping" },
] as const;

const discountTypeOptions = [
  { value: "percentage", labelKey: "admin.promotions.form.discountType.percentage", defaultLabel: "Percentage" },
  { value: "fixed", labelKey: "admin.promotions.form.discountType.fixed", defaultLabel: "Fixed Amount" },
  { value: "bxgy", labelKey: "admin.promotions.form.discountType.bxgy", defaultLabel: "Buy X Get Y" },
  { value: "freeShipping", labelKey: "admin.promotions.form.discountType.freeShipping", defaultLabel: "Free Shipping" },
  { value: "points", labelKey: "admin.promotions.form.discountType.points", defaultLabel: "Bonus Points" },
] as const;

const segmentOptions = [
  { value: "allCustomers", labelKey: "admin.promotions.form.segment.allCustomers", defaultLabel: "All Customers" },
  { value: "firstTime", labelKey: "admin.promotions.form.segment.firstTime", defaultLabel: "First-Time Buyers" },
  { value: "returning", labelKey: "admin.promotions.form.segment.returning", defaultLabel: "Returning Customers" },
  { value: "vip", labelKey: "admin.promotions.form.segment.vip", defaultLabel: "VIP Members" },
  { value: "cartAbandoner", labelKey: "admin.promotions.form.segment.cartAbandoner", defaultLabel: "Cart Abandoners" },
  { value: "inactive", labelKey: "admin.promotions.form.segment.inactive", defaultLabel: "Inactive Users" },
] as const;

const timezoneOptions = [
  { value: "UTC", labelKey: "admin.promotions.form.timezone.utc", defaultLabel: "UTC" },
  { value: "America/Los_Angeles", labelKey: "admin.promotions.form.timezone.pacific", defaultLabel: "Pacific Time (LA)" },
  { value: "America/New_York", labelKey: "admin.promotions.form.timezone.eastern", defaultLabel: "Eastern Time (NY)" },
  { value: "Asia/Bangkok", labelKey: "admin.promotions.form.timezone.bangkok", defaultLabel: "Bangkok" },
  { value: "Europe/London", labelKey: "admin.promotions.form.timezone.london", defaultLabel: "London" },
] as const;

const slugify = (value: string) =>
  value
    .toLowerCase()
    .replace(/[^a-z0-9]+/g, "-")
    .replace(/^-+|-+$/g, "")
    .slice(0, 96);

const buildCampaignId = (value: string) => {
  const base = slugify(value) || "promo";
  const suffix = Math.random().toString(36).slice(-4);
  return `${base}-${suffix}`;
};

const toDateTimeInputValue = (value?: string) => {
  if (!value) return "";
  const date = new Date(value);
  if (Number.isNaN(date.getTime())) return "";

  const pad = (input: number) => `${input}`.padStart(2, "0");
  return `${date.getFullYear()}-${pad(date.getMonth() + 1)}-${pad(date.getDate())}T${pad(date.getHours())}:${pad(date.getMinutes())}`;
};

const buildInitialState = (values?: Partial<PromotionFormState>): PromotionFormState => {
  const now = new Date();
  const defaultEnd = new Date(now.getTime() + 7 * 24 * 60 * 60 * 1000);

  return {
    _id: values?._id,
    name: values?.name ?? "",
    campaignId: values?.campaignId ?? "",
    slug: values?.slug ?? "",
    status: values?.status ?? "draft",
    type: values?.type ?? "flashSale",
    priority: typeof values?.priority === "number" ? values.priority : 50,
    discountType: values?.discountType ?? "percentage",
    discountValue: values?.discountValue,
    minimumOrderValue: values?.minimumOrderValue,
    startDate: toDateTimeInputValue(values?.startDate ?? now.toISOString()),
    endDate: toDateTimeInputValue(values?.endDate ?? defaultEnd.toISOString()),
    timezone: values?.timezone ?? "UTC",
    segmentType: values?.segmentType ?? "allCustomers",
    heroMessage: values?.heroMessage ?? "",
    shortDescription: values?.shortDescription ?? "",
    badgeLabel: values?.badgeLabel ?? "",
    badgeColor: values?.badgeColor ?? "",
    ctaText: values?.ctaText ?? "",
    ctaLink: values?.ctaLink ?? "",
    budgetCap: values?.budgetCap,
    usageLimit: values?.usageLimit,
    perCustomerLimit: values?.perCustomerLimit,
    utmSource: values?.utmSource ?? "",
    utmMedium: values?.utmMedium ?? "",
    utmCampaign: values?.utmCampaign ?? "",
    trackingPixelId: values?.trackingPixelId ?? "",
    internalNotes: values?.internalNotes ?? "",
    defaultProducts: values?.defaultProducts ?? [],
    defaultBundleItems: values?.defaultBundleItems ?? [],
  };
};

type PromotionFormProps = {
  initialValues?: Partial<PromotionFormState>;
  analyticsHref?: string;
  onSubmit: (values: PromotionFormState) => Promise<{
    success: boolean;
    id?: string;
    status?: string;
    message?: string;
  }>;
};

export function PromotionForm({ initialValues, analyticsHref, onSubmit }: PromotionFormProps) {
  const router = useRouter();
  const { toast } = useToast();
  const { t } = useTranslation();
  const resolveMessage = (message: string | undefined, fallbackKey: string) => {
    if (!message) return t(fallbackKey);
    return message.startsWith("admin.") ? t(message) : message;
  };
  const [formState, setFormState] = useState<PromotionFormState>(buildInitialState(initialValues));
  const [slugDirty, setSlugDirty] = useState(Boolean(initialValues?.slug));
  const [campaignDirty, setCampaignDirty] = useState(Boolean(initialValues?.campaignId));
  const [submitError, setSubmitError] = useState<string | null>(null);
  const [isPending, startTransition] = useTransition();
  const optionLabel = (
    options: { value: string; labelKey: string; defaultLabel: string }[],
    value?: string | null,
  ) => {
    if (!value) return "";
    const option = options.find((item) => item.value === value);
    return option ? t(option.labelKey, option.defaultLabel) : value;
  };

  const handleNameChange = (value: string) => {
    setFormState((prev) => ({
      ...prev,
      name: value,
      slug: slugDirty ? prev.slug : slugify(value),
      campaignId: campaignDirty ? prev.campaignId : slugify(value),
    }));
  };

  const handleSlugChange = (value: string) => {
    setSlugDirty(true);
    setFormState((prev) => ({ ...prev, slug: value }));
  };

  const handleCampaignIdChange = (value: string) => {
    setCampaignDirty(true);
    setFormState((prev) => ({ ...prev, campaignId: value }));
  };

  const parseNumberInput = (value: string) => {
    const parsed = Number(value);
    return Number.isNaN(parsed) ? undefined : parsed;
  };

  const handleSubmit = (event: FormEvent<HTMLFormElement>) => {
    event.preventDefault();

    const slugValue = (formState.slug || slugify(formState.name)).trim();
    if (!slugValue) {
      setSubmitError(t("admin.promotions.form.errors.slugRequired"));
      return;
    }

    const campaignValue = (formState.campaignId || slugValue).trim();
    if (!/^[a-z0-9-]+$/.test(campaignValue)) {
      setSubmitError(t("admin.promotions.form.errors.campaignIdInvalid"));
      return;
    }

    if (!formState.startDate || !formState.endDate) {
      setSubmitError(t("admin.promotions.form.errors.dateRequired"));
      return;
    }

    setSubmitError(null);

    const payload: PromotionFormState = {
      ...formState,
      slug: slugValue,
      campaignId: campaignValue,
    };

    startTransition(() => {
      onSubmit(payload)
        .then((result) => {
          if (!result.success) {
            setSubmitError(resolveMessage(result.message, "admin.promotions.form.errors.saveFailed"));
            toast({ description: resolveMessage(result.message, "admin.promotions.form.errors.saveFailedNow") });
            return;
          }

          toast({ description: t("admin.promotions.form.toast.saved") });

          if (!payload._id && result.id) {
            router.replace(`/admin/marketing/promotions/${result.id}`);
          } else if (result.id) {
            setFormState((prev) => ({ ...prev, _id: result.id }));
          }
        })
        .catch((error) => {
          console.error("Failed to save promotion", error);
          setSubmitError(t("admin.promotions.form.errors.saveFailed"));
          toast({ description: t("admin.promotions.form.errors.saveFailedNow") });
        });
    });
  };

  const sections: FormSection[] = useMemo(() => {
    const template = (
      <div className="grid gap-4 md:grid-cols-2">
        <div className="space-y-2">
          <Label htmlFor="type">{t("admin.promotions.form.template.label")}</Label>
          <Select
            value={formState.type}
            onValueChange={(value) => setFormState((prev) => ({ ...prev, type: value }))}
          >
            <SelectTrigger id="type">
              <SelectValue placeholder={t("admin.promotions.form.template.placeholder")} />
            </SelectTrigger>
            <SelectContent>
              {templateOptions.map((option) => (
                <SelectItem key={option.value} value={option.value}>
                  {t(option.labelKey, option.defaultLabel)}
                </SelectItem>
              ))}
            </SelectContent>
          </Select>
        </div>

        <div className="space-y-2">
          <Label htmlFor="priority">{t("admin.promotions.form.priority.label")}</Label>
          <Input
            id="priority"
            type="number"
            value={formState.priority ?? ""}
            onChange={(event) =>
              setFormState((prev) => ({
                ...prev,
                priority: parseNumberInput(event.target.value),
              }))
            }
            placeholder={t("admin.promotions.form.priority.placeholder")}
          />
        </div>

        <div className="md:col-span-2 rounded-lg border border-slate-200 bg-slate-50 p-3 text-sm text-slate-700">
          {t("admin.promotions.form.template.hint")}
        </div>
      </div>
    );

    const basics = (
      <div className="grid gap-4 md:grid-cols-2">
        <div className="space-y-2">
          <Label htmlFor="name">{t("admin.promotions.form.basics.name")}</Label>
          <Input
            id="name"
            value={formState.name}
            onChange={(event) => handleNameChange(event.target.value)}
            placeholder={t("admin.promotions.form.basics.namePlaceholder")}
          />
        </div>

        <div className="space-y-2">
          <div className="flex items-center justify-between">
            <Label htmlFor="slug">{t("admin.promotions.form.basics.slug")}</Label>
            <Button
              variant="ghost"
              size="sm"
              type="button"
              onClick={() => handleSlugChange(slugify(formState.name))}
            >
              {t("admin.promotions.form.basics.regenerate")}
            </Button>
          </div>
          <Input
            id="slug"
            value={formState.slug}
            onChange={(event) => handleSlugChange(event.target.value)}
            placeholder={t("admin.promotions.form.basics.slugPlaceholder")}
          />
        </div>

        <div className="space-y-2">
          <div className="flex items-center justify-between">
            <Label htmlFor="campaignId">{t("admin.promotions.form.basics.campaignId")}</Label>
            <Button
              variant="ghost"
              size="sm"
              type="button"
              onClick={() => handleCampaignIdChange(buildCampaignId(formState.name || "promo"))}
            >
              {t("admin.promotions.form.basics.generateId")}
            </Button>
          </div>
          <Input
            id="campaignId"
            value={formState.campaignId}
            onChange={(event) => handleCampaignIdChange(event.target.value)}
            placeholder={t("admin.promotions.form.basics.campaignIdPlaceholder")}
          />
        </div>

        <div className="space-y-2">
          <Label htmlFor="status">{t("admin.promotions.form.basics.status")}</Label>
          <Select
            value={formState.status}
            onValueChange={(value) => setFormState((prev) => ({ ...prev, status: value }))}
          >
            <SelectTrigger id="status">
              <SelectValue placeholder={t("admin.promotions.form.basics.statusPlaceholder")} />
            </SelectTrigger>
            <SelectContent>
              {statusOptions.map((option) => (
                <SelectItem key={option.value} value={option.value}>
                  {t(option.labelKey, option.defaultLabel)}
                </SelectItem>
              ))}
            </SelectContent>
          </Select>
        </div>
      </div>
    );

    const discount = (
      <div className="grid gap-4 md:grid-cols-2">
        <div className="space-y-2">
          <Label htmlFor="discountType">{t("admin.promotions.form.discount.type")}</Label>
          <Select
            value={formState.discountType}
            onValueChange={(value) => setFormState((prev) => ({ ...prev, discountType: value }))}
          >
            <SelectTrigger id="discountType">
              <SelectValue placeholder={t("admin.promotions.form.discount.typePlaceholder")} />
            </SelectTrigger>
            <SelectContent>
              {discountTypeOptions.map((option) => (
                <SelectItem key={option.value} value={option.value}>
                  {t(option.labelKey, option.defaultLabel)}
                </SelectItem>
              ))}
            </SelectContent>
          </Select>
        </div>

        {formState.discountType !== "freeShipping" && formState.discountType !== "bxgy" && (
          <div className="space-y-2">
            <Label htmlFor="discountValue">{t("admin.promotions.form.discount.value")}</Label>
            <Input
              id="discountValue"
              type="number"
              value={formState.discountValue ?? ""}
              onChange={(event) =>
                setFormState((prev) => ({
                  ...prev,
                  discountValue: parseNumberInput(event.target.value),
                }))
              }
              placeholder={t("admin.promotions.form.discount.valuePlaceholder")}
            />
          </div>
        )}

        <div className="space-y-2">
          <Label htmlFor="minimumOrderValue">{t("admin.promotions.form.discount.minimumOrderValue")}</Label>
          <Input
            id="minimumOrderValue"
            type="number"
            value={formState.minimumOrderValue ?? ""}
            onChange={(event) =>
              setFormState((prev) => ({
                ...prev,
                minimumOrderValue: parseNumberInput(event.target.value),
              }))
            }
            placeholder={t("admin.promotions.form.discount.minimumOrderPlaceholder")}
          />
        </div>

        <div className="md:col-span-2 rounded-lg border border-slate-200 bg-slate-50 p-3 text-sm text-slate-700">
          {t("admin.promotions.form.discount.hint")}
        </div>
      </div>
    );

    const targeting = (
      <div className="grid gap-4 md:grid-cols-2">
        <div className="space-y-2">
          <Label htmlFor="segmentType">{t("admin.promotions.form.targeting.segment")}</Label>
          <Select
            value={formState.segmentType}
            onValueChange={(value) => setFormState((prev) => ({ ...prev, segmentType: value }))}
          >
            <SelectTrigger id="segmentType">
              <SelectValue placeholder={t("admin.promotions.form.targeting.segmentPlaceholder")} />
            </SelectTrigger>
            <SelectContent>
              {segmentOptions.map((option) => (
                <SelectItem key={option.value} value={option.value}>
                  {t(option.labelKey, option.defaultLabel)}
                </SelectItem>
              ))}
            </SelectContent>
          </Select>
        </div>

        <div className="md:col-span-2 rounded-lg border border-dashed border-slate-200 bg-slate-50 p-3 text-sm text-slate-700">
          {t("admin.promotions.form.targeting.hint")}
        </div>
      </div>
    );

    const creative = (
      <div className="grid gap-4 md:grid-cols-2">
        <div className="space-y-2">
          <Label htmlFor="badgeLabel">{t("admin.promotions.form.creative.badgeLabel")}</Label>
          <Input
            id="badgeLabel"
            value={formState.badgeLabel}
            onChange={(event) => setFormState((prev) => ({ ...prev, badgeLabel: event.target.value }))}
            placeholder={t("admin.promotions.form.creative.badgeLabelPlaceholder")}
          />
        </div>

        <div className="space-y-2">
          <Label htmlFor="badgeColor">{t("admin.promotions.form.creative.badgeColor")}</Label>
          <Input
            id="badgeColor"
            value={formState.badgeColor}
            onChange={(event) => setFormState((prev) => ({ ...prev, badgeColor: event.target.value }))}
            placeholder={t("admin.promotions.form.creative.badgeColorPlaceholder")}
          />
        </div>

        <div className="space-y-2 md:col-span-2">
          <Label htmlFor="heroMessage">{t("admin.promotions.form.creative.heroMessage")}</Label>
          <Textarea
            id="heroMessage"
            value={formState.heroMessage}
            onChange={(event) => setFormState((prev) => ({ ...prev, heroMessage: event.target.value }))}
            rows={2}
            placeholder={t("admin.promotions.form.creative.heroMessagePlaceholder")}
          />
        </div>

        <div className="space-y-2 md:col-span-2">
          <Label htmlFor="shortDescription">{t("admin.promotions.form.creative.shortDescription")}</Label>
          <Input
            id="shortDescription"
            value={formState.shortDescription}
            onChange={(event) =>
              setFormState((prev) => ({ ...prev, shortDescription: event.target.value }))
            }
            placeholder={t("admin.promotions.form.creative.shortDescriptionPlaceholder")}
          />
        </div>

        <div className="space-y-2">
          <Label htmlFor="ctaText">{t("admin.promotions.form.creative.ctaText")}</Label>
          <Input
            id="ctaText"
            value={formState.ctaText}
            onChange={(event) => setFormState((prev) => ({ ...prev, ctaText: event.target.value }))}
            placeholder={t("admin.promotions.form.creative.ctaTextPlaceholder")}
          />
        </div>

        <div className="space-y-2">
          <Label htmlFor="ctaLink">{t("admin.promotions.form.creative.ctaLink")}</Label>
          <Input
            id="ctaLink"
            value={formState.ctaLink}
            onChange={(event) => setFormState((prev) => ({ ...prev, ctaLink: event.target.value }))}
            placeholder={t("admin.promotions.form.creative.ctaLinkPlaceholder")}
          />
        </div>
      </div>
    );

    const schedule = (
      <div className="grid gap-4 md:grid-cols-2">
        <div className="space-y-2">
          <Label htmlFor="startDate">{t("admin.promotions.form.schedule.startDate")}</Label>
          <Input
            id="startDate"
            type="datetime-local"
            value={formState.startDate}
            onChange={(event) => setFormState((prev) => ({ ...prev, startDate: event.target.value }))}
          />
        </div>

        <div className="space-y-2">
          <Label htmlFor="endDate">{t("admin.promotions.form.schedule.endDate")}</Label>
          <Input
            id="endDate"
            type="datetime-local"
            value={formState.endDate}
            onChange={(event) => setFormState((prev) => ({ ...prev, endDate: event.target.value }))}
          />
        </div>

        <div className="space-y-2">
          <Label htmlFor="timezone">{t("admin.promotions.form.schedule.timezone")}</Label>
          <Select
            value={formState.timezone}
            onValueChange={(value) => setFormState((prev) => ({ ...prev, timezone: value }))}
          >
            <SelectTrigger id="timezone">
              <SelectValue placeholder={t("admin.promotions.form.schedule.timezonePlaceholder")} />
            </SelectTrigger>
            <SelectContent>
              {timezoneOptions.map((option) => (
                <SelectItem key={option.value} value={option.value}>
                  {t(option.labelKey, option.defaultLabel)}
                </SelectItem>
              ))}
            </SelectContent>
          </Select>
        </div>
      </div>
    );

    const limits = (
      <div className="grid gap-4 md:grid-cols-3">
        <div className="space-y-2">
          <Label htmlFor="budgetCap">{t("admin.promotions.form.limits.budgetCap")}</Label>
          <Input
            id="budgetCap"
            type="number"
            value={formState.budgetCap ?? ""}
            onChange={(event) =>
              setFormState((prev) => ({ ...prev, budgetCap: parseNumberInput(event.target.value) }))
            }
            placeholder={t("admin.promotions.form.limits.unlimitedPlaceholder")}
          />
        </div>

        <div className="space-y-2">
          <Label htmlFor="usageLimit">{t("admin.promotions.form.limits.usageLimit")}</Label>
          <Input
            id="usageLimit"
            type="number"
            value={formState.usageLimit ?? ""}
            onChange={(event) =>
              setFormState((prev) => ({ ...prev, usageLimit: parseNumberInput(event.target.value) }))
            }
            placeholder={t("admin.promotions.form.limits.unlimitedPlaceholder")}
          />
        </div>

        <div className="space-y-2">
          <Label htmlFor="perCustomerLimit">{t("admin.promotions.form.limits.perCustomerLimit")}</Label>
          <Input
            id="perCustomerLimit"
            type="number"
            value={formState.perCustomerLimit ?? ""}
            onChange={(event) =>
              setFormState((prev) => ({
                ...prev,
                perCustomerLimit: parseNumberInput(event.target.value),
              }))
            }
            placeholder={t("admin.promotions.form.limits.perCustomerPlaceholder")}
          />
        </div>
      </div>
    );

    const advanced = (
      <div className="grid gap-4 md:grid-cols-2">
        <div className="space-y-2">
          <Label htmlFor="utmSource">{t("admin.promotions.form.advanced.utmSource")}</Label>
          <Input
            id="utmSource"
            value={formState.utmSource}
            onChange={(event) => setFormState((prev) => ({ ...prev, utmSource: event.target.value }))}
            placeholder={t("admin.promotions.form.advanced.utmSourcePlaceholder")}
          />
        </div>

        <div className="space-y-2">
          <Label htmlFor="utmMedium">{t("admin.promotions.form.advanced.utmMedium")}</Label>
          <Input
            id="utmMedium"
            value={formState.utmMedium}
            onChange={(event) => setFormState((prev) => ({ ...prev, utmMedium: event.target.value }))}
            placeholder={t("admin.promotions.form.advanced.utmMediumPlaceholder")}
          />
        </div>

        <div className="space-y-2">
          <Label htmlFor="utmCampaign">{t("admin.promotions.form.advanced.utmCampaign")}</Label>
          <Input
            id="utmCampaign"
            value={formState.utmCampaign}
            onChange={(event) => setFormState((prev) => ({ ...prev, utmCampaign: event.target.value }))}
            placeholder={t("admin.promotions.form.advanced.utmCampaignPlaceholder")}
          />
        </div>

        <div className="space-y-2">
          <Label htmlFor="trackingPixelId">{t("admin.promotions.form.advanced.trackingPixelId")}</Label>
          <Input
            id="trackingPixelId"
            value={formState.trackingPixelId}
            onChange={(event) =>
              setFormState((prev) => ({ ...prev, trackingPixelId: event.target.value }))
            }
            placeholder={t("admin.promotions.form.advanced.trackingPixelPlaceholder")}
          />
        </div>

        <div className="space-y-2 md:col-span-2">
          <Label htmlFor="internalNotes">{t("admin.promotions.form.advanced.internalNotes")}</Label>
          <Textarea
            id="internalNotes"
            value={formState.internalNotes}
            onChange={(event) =>
              setFormState((prev) => ({ ...prev, internalNotes: event.target.value }))
            }
            rows={3}
            placeholder={t("admin.promotions.form.advanced.internalNotesPlaceholder")}
          />
        </div>
      </div>
    );

    return [
      {
        id: "template",
        label: t("admin.promotions.form.sections.template"),
        description: t("admin.promotions.form.sections.templateDesc"),
        content: template,
      },
      {
        id: "basics",
        label: t("admin.promotions.form.sections.basics"),
        description: t("admin.promotions.form.sections.basicsDesc"),
        content: basics,
      },
      {
        id: "discount",
        label: t("admin.promotions.form.sections.discount"),
        description: t("admin.promotions.form.sections.discountDesc"),
        content: discount,
      },
      {
        id: "targeting",
        label: t("admin.promotions.form.sections.targeting"),
        description: t("admin.promotions.form.sections.targetingDesc"),
        content: targeting,
      },
      {
        id: "creative",
        label: t("admin.promotions.form.sections.creative"),
        description: t("admin.promotions.form.sections.creativeDesc"),
        content: creative,
      },
      {
        id: "schedule",
        label: t("admin.promotions.form.sections.schedule"),
        description: t("admin.promotions.form.sections.scheduleDesc"),
        content: schedule,
      },
      {
        id: "limits",
        label: t("admin.promotions.form.sections.limits"),
        description: t("admin.promotions.form.sections.limitsDesc"),
        content: limits,
      },
      {
        id: "advanced",
        label: t("admin.promotions.form.sections.advanced"),
        description: t("admin.promotions.form.sections.advancedDesc"),
        content: advanced,
      },
    ];
  }, [formState, t]);

  return (
    <form onSubmit={handleSubmit} className="space-y-4">
      <div className="flex flex-col gap-3 rounded-lg border border-slate-200 bg-slate-50 p-4 md:flex-row md:items-center md:justify-between">
        <div className="space-y-1">
          <p className="text-sm font-semibold text-slate-900">
            {formState.name || t("admin.promotions.form.header.newDraft")}
          </p>
          <p className="text-xs text-slate-600">
            {t("admin.promotions.form.header.hint")}
          </p>
          {formState.campaignId && (
            <Badge variant="outline" className="text-xs font-medium">
              {t("admin.promotions.form.header.campaignId", { id: formState.campaignId })}
            </Badge>
          )}
        </div>
        <div className="flex flex-wrap items-center gap-2">
          {analyticsHref && (
            <Button variant="outline" size="sm" type="button" asChild>
              <Link href={analyticsHref}>{t("admin.promotions.form.actions.viewAnalytics")}</Link>
            </Button>
          )}
          {formState.status && <StatusBadge status={formState.status} />}
          <Button type="submit" disabled={isPending}>
            {isPending ? t("admin.promotions.form.actions.saving") : formState._id ? t("admin.promotions.form.actions.save") : t("admin.promotions.form.actions.create")}
          </Button>
        </div>
      </div>

      {submitError && (
        <div className="rounded-lg border border-red-200 bg-red-50 p-3 text-sm text-red-700">
          {submitError}
        </div>
      )}

      <FormTabs sections={sections} defaultSection="template" />
    </form>
  );
}
