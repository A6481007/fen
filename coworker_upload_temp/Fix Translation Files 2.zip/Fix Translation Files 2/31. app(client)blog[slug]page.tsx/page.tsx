import BlogArticlePageClient from "./BlogArticlePageClient";
import { getBlogCategories, getCategories, getOthersBlog, getSingleBlog } from "@/sanity/queries";
import type { BLOG_CATEGORIESResult, OTHERS_BLOG_QUERYResult } from "@/sanity.types";
import { notFound } from "next/navigation";

const SingleBlogPage = async ({
  params,
}: {
  params: Promise<{ slug: string }>;
}) => {
  const { slug } = await params;
  const blog = await getSingleBlog(slug);

  if (!blog) return notFound();

  type BlogCategoryEntry = BLOG_CATEGORIESResult[number] & {
    blogcategories?: { _key?: string; title?: string | null }[];
  };
  type RelatedBlog = OTHERS_BLOG_QUERYResult[number] & {
    _id?: string | null;
    publishedAt?: string | null;
  };

  const productCategories = ((await getCategories(6)) || []).filter(
    (category) => category?.isParentCategory
  );
  const blogCategories = ((await getBlogCategories()) ?? []) as BlogCategoryEntry[];
  const latestBlogs = ((await getOthersBlog(slug, 5)) ?? []) as RelatedBlog[];

  return (
    <BlogArticlePageClient
      article={blog}
      productCategories={productCategories}
      blogCategories={blogCategories}
      latestBlogs={latestBlogs}
    />
  );
};

export default SingleBlogPage;
