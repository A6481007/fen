﻿"use client";

import { Product, BRAND_QUERYResult } from "@/sanity.types";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Package, Truck, Shield, Award } from "lucide-react";
import { useTranslation } from "react-i18next";

interface ProductSpecsProps {
  product: Product;
  brand: BRAND_QUERYResult | null;
}

const ProductSpecs = ({ product, brand }: ProductSpecsProps) => {
  const { t } = useTranslation();
  const sku =
    (product as any)?.sku ||
    product?.slug?.current ||
    product?._id?.slice(-8) ||
    "";
  const brandName =
    (brand && brand[0]?.brandName) ||
    (product as any)?.brand?.title ||
    (product as any)?.brandName ||
    "Brand";
  const shipping = (product as any)?.shipping || {};
  const warranty =
    (product as any)?.warranty || t("client.productSpecs.warranty.default");
  const returnPolicy =
    (product as any)?.returnPolicy || t("client.productSpecs.warranty.returnPolicy");
  const qualityBadges =
    ((product as any)?.qualityBadges as string[] | undefined)?.filter(Boolean) ||
    [
      t("client.productSpecs.quality.tested"),
      t("client.productSpecs.quality.authentic"),
      t("client.productSpecs.quality.packaging"),
    ];

  return (
    <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4 mt-8">
      {/* Product Features */}
      <Card className="border-2 border-gray-100 hover:border-brand-text-main/30 transition-colors">
        <CardHeader className="pb-3">
          <div className="flex items-center gap-2">
            <Package className="h-5 w-5 text-brand-red-accent" />
            <CardTitle className="text-sm font-semibold">
              {t("client.productSpecs.productInfo.title")}
            </CardTitle>
          </div>
        </CardHeader>
        <CardContent className="space-y-2">
          <div className="flex justify-between text-sm">
            <span className="text-gray-600">
              {t("client.productSpecs.productInfo.stock")}
            </span>
            <Badge
              variant={product?.stock === 0 ? "destructive" : "default"}
              className={
                product?.stock === 0
                  ? ""
                  : "bg-success-highlight text-success-base hover:bg-success-highlight"
              }
            >
              {product?.stock === 0
                ? t("client.productDetails.stock.outOfStock")
                : t("client.productSpecs.productInfo.available", {
                    count: product?.stock ?? 0,
                  })}
            </Badge>
          </div>
          <div className="flex justify-between text-sm">
            <span className="text-gray-600">
              {t("client.productSpecs.productInfo.brand")}
            </span>
            <span className="font-medium">{brandName}</span>
          </div>
          <div className="flex justify-between text-sm">
            <span className="text-gray-600">
              {t("client.productSpecs.productInfo.sku")}
            </span>
            <span className="font-medium text-xs text-gray-500">
              #{String(sku).toUpperCase()}
            </span>
          </div>
        </CardContent>
      </Card>

      {/* Shipping Info */}
      <Card className="border-2 border-gray-100 hover:border-brand-text-main/30 transition-colors">
        <CardHeader className="pb-3">
          <div className="flex items-center gap-2">
            <Truck className="h-5 w-5 text-brand-red-accent" />
            <CardTitle className="text-sm font-semibold">{t("client.productSpecs.shipping.title")}</CardTitle>
          </div>
        </CardHeader>
        <CardContent className="space-y-2 text-sm">
          <div className="flex items-center gap-2">
            <span className="text-success-base font-medium">
              {shipping.freeShipping === false ? t("client.productSpecs.shipping.available") : t("client.productSpecs.shipping.free")}
            </span>
          </div>
          <div className="text-gray-600">
            {shipping.estimate || t("client.productSpecs.shipping.estimateDefault")}
          </div>
          <div className="text-gray-600">
            {shipping.expressEstimate || t("client.productSpecs.shipping.expressDefault")}
          </div>
        </CardContent>
      </Card>

      {/* Warranty */}
      <Card className="border-2 border-gray-100 hover:border-brand-text-main/30 transition-colors">
        <CardHeader className="pb-3">
          <div className="flex items-center gap-2">
            <Shield className="h-5 w-5 text-brand-red-accent" />
            <CardTitle className="text-sm font-semibold">
              {t("client.productSpecs.warranty.title")}
            </CardTitle>
          </div>
        </CardHeader>
        <CardContent className="space-y-2 text-sm">
          <div className="text-gray-600">
            <span className="font-medium text-brand-black-strong">
              {warranty}
            </span>
          </div>
          <div className="text-gray-600">
            <span className="font-medium text-brand-black-strong">
              {returnPolicy}
            </span>
          </div>
          <div className="text-gray-600">
            {t("client.productSpecs.warranty.techSupport")}
          </div>
        </CardContent>
      </Card>

      {/* Quality Assurance */}
      <Card className="border-2 border-gray-100 hover:border-brand-text-main/30 transition-colors">
        <CardHeader className="pb-3">
          <div className="flex items-center gap-2">
            <Award className="h-5 w-5 text-brand-red-accent" />
            <CardTitle className="text-sm font-semibold">
              {t("client.productSpecs.quality.title")}
            </CardTitle>
          </div>
        </CardHeader>
        <CardContent className="space-y-2 text-sm">
          {qualityBadges.map((badge) => (
            <div className="flex items-center gap-2" key={badge}>
              <span className="text-success-base font-medium">✓ {badge}</span>
            </div>
          ))}
        </CardContent>
      </Card>
    </div>
  );
};

export default ProductSpecs;

